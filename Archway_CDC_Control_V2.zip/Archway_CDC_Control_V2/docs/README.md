# Archway Direct SQL Server CDC — two-customer, two-table pilot (V2)

**Scope:** ATWeb `dbo.SecurityValue` and `dbo.OpenPosition`; customers Little Hawk (2020082401) and Mitzman Family (2021080300); existing `archway_uc_dev_dw` catalog. **No source or Databricks changes were executed** while preparing this package. All provisioning must be approved and run by an authorized operator. This is a pilot, not a certified production release.

## What changed versus V1

V1 only created a subset of controls. V2 creates **all nine requested** `etl_control` tables, seeds four configuration tables and eight independent checkpoints, and has executable-stage writers for the other four tables (runs, affected scope, reconciliations and provisional cost allocation). A successful first CDC-only run cannot create `affected_scope` unless source changes exist; it deliberately does not generate fictitious events.

## Architecture and ownership

```text
ATWeb SQL Server (all customers; CDC per table)
    |  SQL Server Agent captures change rows in SQL Server cdc schema
    |  Notebook EXTRACT reads LSN ranges using fn_cdc_get_all_changes_*
    v
archway_uc_dev_dw.landing_history.cdc_events    [all-customer immutable event journal]
    |                       |
    | LANDING task          | customer BRONZE_SILVER task (two customer consumer checkpoints)
    v                       +-> little_hawk_bronze.cdc_events -> little_hawk_silver.{securityvalue,openposition}
landing.{securityvalue,       +-> mitzman_bronze.cdc_events    -> mitzman_silver.{securityvalue,openposition}
         openposition}      [each customer's Bronze has immutable CDC events]
    |                       |
    +-----------------------+-> RECONCILE compares latest landing state to each customer Silver
                                 -> reconciliations + impact scope + per-customer cost-share
etl_control (nine tables) configures and records every hop.
```

**Landing is a synchronized latest-state copy of all customers.** It retains historical **business-dated rows** still present in the source, not every revision ever made to each row. **Landing History** retains the source mutations observed **after CDC was enabled**, plus a documented initial baseline, when the source capture and retention preserve them. Customer Bronze is **append-only source events**, so it deliberately contains repeated source keys. Customer Silver contains **one current row per source key**. `OpenPosition` source key is the tuple `(OpenPositionID, Date)`; `SecurityValue` key is `SecurityValueID`.

## Stage-by-stage implementation

### A — SQL Server DBA work (once)

1. Run `sql/01_sqlserver_cdc.sql` discovery statements in SSMS, without uncommenting any DDL. Confirm `ATWeb` edition and agent support, existing capture instances, PKs, DB CDC status, CDC/CT settings and cleanup retention. **Database CDC must be enabled in ATWeb context**, not `master`.
2. Have a SQL Server DBA approve and execute database CDC enablement (only if needed) and `sp_cdc_enable_table` once each for `SecurityValue` and `OpenPosition`; use capture instances `dbo_SecurityValue` and `dbo_OpenPosition`. Verify the CDC capture/cleanup agent jobs are running and extraction principal has necessary SELECT/CDC role access. Read [Microsoft CDC enable procedure](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sys-sp-cdc-enable-table-transact-sql).
3. Retention must exceed the worst-case ingestion outage, not simply the expected one-hour interval; seven days is an illustrative starting point subject to operational approval. A captured LSN older than retained changes must STOP the job, not silently advance.
4. Source tables can have nullable CustomerID fields. The pilot routes only rows with the matching explicit customer ID. Unresolved/other-customer records remain in shared Landing and journal. For production, define source-specific, historical Fund/Portfolio/Security ownership resolution before expanding routing.

### B — Databricks platform and tables (once)

5. Confirm Unity Catalog **ownership, managed ADLS location and service principal permissions**. Deploy the proposed `sql/02_uc_all_objects.sql` in a **nonproduction** catalog first; this creates landing, landing_history, etl_control and the four customer Bronze/Silver schemas plus all required tables. The two source current-state mirrors and customer Silver tables retain all selected source fields in `payload_json`, plus typed identifiers/dates.
6. Execute `sql/03_seed_all_metadata.sql`. Check `sql/04_read_only_checks.sql`. Expected pre-run configuration row counts: source_table_config=2, customer_registry=2, customer_table_scope=4, pipeline_dependencies=14, consumer_checkpoints=8. Other four operational tables begin empty. If tables pre-exist with inconsistent schema/data, **do not force-merge**; reconcile manually.
7. Create a Databricks secret scope named `archway-cdc`, with `sqlserver-jdbc-url` (JDBC `databaseName=ATWeb;encrypt=true` with correct certificate validation), `username`, `password`. Confirm network path and least-privilege SQL credentials. Never commit passwords to source control.
8. Import `notebooks/00_cdc_pilot_driver.py` as a Databricks notebook, or package it with the attached Asset Bundle after converting/uploading as a notebook. Validate that the driver can read the seeded metadata before running any data operation. Do not grant dev users CREATE SCHEMA/TABLE if they only need data write permissions.

### C — Consistent baseline (one-time; manual and coordinated)

9. Schedule a **short source write pause for both pilot tables** (including transaction writers and SQL maintenance) or design an equivalent consistent, transactionally coordinated snapshot. Wait until SQL Server CDC capture has caught up to all commits prior to the pause, and record a common audited cutoff. This pilot code samples `fn_cdc_get_max_lsn` for each table while writes remain paused. **Without this pause, snapshot and CDC can skip or duplicate data and counts are not defensible.**
10. Run `EXTRACT` with `mode=BASELINE` separately for SecurityValue and OpenPosition. It reads **all customers** from the two SQL Server source tables into shared journal as `operation=0 BASELINE` events and seals a per-table SOURCE checkpoint at the source high LSN. Do NOT run baseline again after its checkpoint is established.
11. Run `LANDING` for each table; it replays baseline events into latest-state shared Landing. Then run `BRONZE_SILVER` for `(SecurityValue, 2020082401)`, `(SecurityValue, 2021080300)`, `(OpenPosition, 2020082401)`, `(OpenPosition, 2021080300)`. Run `RECONCILE` for each pair. **All four reconciliation checks must PASS** before the source write pause ends / hourly CDC is enabled.
12. Record baseline SQL Server `COUNT(*)` and customer counts using a consistent read and verify Landing all-customer counts, each customer Silver count, uniqueness and row values. The starter `RECONCILE` compares Landing vs Silver; source vs Landing should be added to the release evidence. Do not pretend a successful job alone proves complete history.

### D — Hourly CDC mode after baseline

13. After source writes resume, `EXTRACT(mode=CDC)` reads CDC LSNs in the half-open *after last high LSN through new high LSN* interval using SQL Server `fn_cdc_get_all_changes_<capture_instance>(..., 'all update old')`. It **MERGEs** event records idempotently by deterministic event_id into shared landing_history and only then advances the SOURCE checkpoint. SQL Server operations: `1=DELETE`, `2=INSERT`, `3=UPDATE_BEFORE`, `4=UPDATE_AFTER`.
14. `LANDING` uses its **own** checkpoint, replays the journal into shared current-state landing via Delta MERGE and advances LANDING only after success.
15. Four customer tasks independently select journal events by `customer_id`, append them to their own Bronze event journal (MERGE on immutable event_id avoids retry duplicates), select **latest** operation per full source key by source LSN/seq and apply to Silver. BEFORE images are kept in Bronze but not applied as Silver state; deletes remove source key. Each customer source checkpoint advances only after Silver and Bronze and impact rows were committed. Customers without changes still advance their checkpoints to the sealed source high LSN.
16. `affected_scope` records incremental CDC changes only (not initial BASELINE rows) for each changed SecurityID, PortfolioID and business effective date for later IBOR/ABOR processing. `FundID` is **NULL** and status is **PENDING_FUND_RESOLUTION** until an approved temporal Portfolio → Fund / valuation dependency resolver is built. Thus this pilot does **not** make Gold-ready claims.
17. `RECONCILE` compares current-state Landing vs each customer Silver (count, source key, payload and duplicate keys). Any failed reconciliation fails the job and records an explicit FAIL result; retry is safe. `COST` writes **customer event-count shares** for the run; billed USD and DBU remain NULL until matched to `system.billing.usage` and approved pricing/attribution logic. Never interpret event-volume shares as actual billed costs.

### E — Databricks Jobs / deployment

18. Validate the generated `databricks.yml` using the Databricks CLI (`databricks bundle validate -t dev`), inspect plan and permissions and deploy only with authorization. Both jobs are intentionally created **PAUSED** and must remain paused until the baseline is signed off. Bundle deployment is not an ETL execution. Install/import the notebook at `/Workspace/Shared/Archway/CDC/00_cdc_pilot_driver` or adjust the bundle paths before deployment.
19. Jobs: `archway_cdc_securityvalue_hourly` and `archway_cdc_openposition_hourly`. Each job runs `EXTRACT -> LANDING -> {two parallel customer BRONZE_SILVER} -> {two RECONCILE} -> COST` with one shared `run_id` per run. Use maximum concurrent runs **1 per source**; future scale requires a separate cap on concurrent JDBC extractions.
20. **Do not deploy or unpause the hourly jobs before initial baseline and parity sign-off.** For initial baseline, use the exact same stages manually in sequence with `mode=BASELINE` for EXTRACT and a shared documented run id; verify each output in ETL Control. After baseline complete, enable CDC jobs, `mode=CDC`, hourly schedule.

## The NINE control tables: who writes what

| Control table | Seed / configuration records | Runtime writer | Operational purpose |
|---|---|---|---|
| `source_table_config` | 2 tables, PK definitions, source column lists, CDC instances | Administrator / approved seed | Source metadata, drives JDBC query, keys, payload routing |
| `customer_registry` | 2 customers with schema paths and cost centers | Administrator / approved seed | Customer-specific physical destination and security partition |
| `customer_table_scope` | 4 source/customer combinations, initially baseline_completed=false | BRONZE_SILVER sets baseline_completed=true after success | Eligible routing; customer x source status |
| `pipeline_dependencies` | 14 DAG edges and destination tables | Administrator / approved seed | Runtime verifies configured task exists and enabled |
| `consumer_checkpoints` | 8 source/landing/customer consumer rows, null LSN initial | EXTRACT, LANDING, BRONZE_SILVER | Exact source LSN replay boundaries, independent stages/customers |
| `pipeline_runs` | Empty before first execution | **every task** | Completed/Failed status, stage, row counts, checkpoint intervals |
| `affected_scope` | Empty before first data events | BRONZE_SILVER | Source CDC event → affected customer/security/portfolio/date |
| `reconciliation_results` | Empty before first test | RECONCILE | Persist PASS/FAIL vs Landing, mismatch counts |
| `customer_cost_allocation` | Empty before first costing | COST | Provisional event-share weights, USD NULL pending billing attribution |

## Test matrix and expected response

- Insert a new `SecurityValue` for Little Hawk → shared journal + Landing + LH Bronze + LH Silver; Mitzman unchanged. Confirm one new `affected_scope` entry.
- Change `SecurityValue` twice between hourly runs → two SQL Server updates produce four CDC image rows in the shared journal; customer Bronze preserves them and customer Silver has latest after-image only.
- Delete an `OpenPosition` row → shared journal records delete, customer Bronze retains it, customer Silver removes the exact `(OpenPositionID, Date)` key.
- Change old `SecurityValueDate` or `OpenPosition.Date` → source source-key/date handling must be validated; an OpenPosition PK date move may be delete+insert. Source routing owner changes on updates are blocked by the pilot until explicit old/new propagation exists.
- Source value for October 27 modified in November → source LSN drives extraction; October 27 is retained in `affected_scope`, and a separate IBOR Gold stage can later determine all impacted dates.
- Retry EXTRACT after journal success but before source checkpoint -> idempotent history MERGE by event_id.
- Retry BRONZE_SILVER after a partial commit -> Bronze event MERGE and Silver LSN-aware merge; checkpoint advances only after both succeed.
- Leave SQL Server extractor down past CDC cleanup -> **stop** on CDC retention gap; do not silently skip.

## Known pilot limitations / necessary production hardening

1. The two source tables have nullable customer columns. They route only direct matching CustomerIDs; resolving null customer ownership from versioned relationships is a separate approved design task. Capture journal can contain null customer id; those rows are intentionally not routed.
2. No global transaction across Delta journal, Landing, Bronze, Silver and control tables. Each stage is checkpointed and idempotent; recovery/retry must be tested against partial failures. DBX jobs per-source concurrency=1 is a critical control.
3. Spark JDBC all-changes extraction currently reads an LSN range without paging. Before production, implement bounded LSN chunking, JDBC partition design that preserves exact event identities, data volume tests, and backpressure limits.
4. For capture instances that CDC did not record all expected payload columns, `EXTRACT` will fail until the captured column set is reconciled; never silently omit business fields.
5. Fund hierarchy and Gold IBOR/ABOR impact expansion are out of this two-table Bronze/Silver pilot; source `PortfolioID` is captured but `FundID` is not inferred.
6. `customer_cost_allocation` produces workload shares, **not** actual billing; no dollar/DBU chargeback without system usage attribution.
7. CDC cannot reconstruct pre-enablement changes. Baseline is original source state, not a historical transaction journal.
8. **No integration tests have been executed.** Reconcile raw SQL Server snapshots and behavior in an authorized test environment before relying on outputs.

## Quick command/order reference

1. SQL Server: `sql/01_sqlserver_cdc.sql` discovery; DBA enables CDC.
2. Databricks SQL: `sql/02_uc_all_objects.sql` → `sql/03_seed_all_metadata.sql`.
3. Databricks SQL: `sql/04_read_only_checks.sql` should show **2/2/4/14/8/0/0/0/0** for the nine controls on a fresh schema.
4. Initial controlled snapshots: driver stage `EXTRACT`, mode `BASELINE`, per source.
5. Driver stage `LANDING`, per source.
6. Driver stage `BRONZE_SILVER`, for both customers x both sources.
7. Driver stage `RECONCILE`, for both customers x both sources.
8. Driver stage `COST`, per source (optional for baseline).
9. Confirm PASS and source-to-target parity; then enable paused Databricks Jobs for hourly CDC.

Official docs: [SQL Server CDC table enablement](https://learn.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sys-sp-cdc-enable-table-transact-sql/) · [CDC all changes function](https://learn.microsoft.com/en-us/sql/relational-databases/system-functions/cdc-fn-cdc-get-all-changes-capture-instance-transact-sql) · [Databricks Job parameters](https://learn.microsoft.com/en-us/azure/databricks/jobs/parameters) · [Delta CDF](https://learn.microsoft.com/en-us/azure/databricks/delta/delta-change-data-feed).
