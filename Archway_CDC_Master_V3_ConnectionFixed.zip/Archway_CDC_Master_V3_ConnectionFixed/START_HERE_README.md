# Archway — ONE MASTER JOB — start here

**Version 3 pilot — 12 November 2026.** Prepared for two customers and two SQL Server source tables, based on supplied ATWeb DDL. No changes have been made to your SQL Server or Databricks account. SQL scripts must be reviewed before execution. The Python code has syntax checks but has **NOT** passed integration testing.

## What you are building

You create **ONE Databricks Job** with **ONE Notebook task**, named `JOB_ARCHWAY_CDC_MASTER`. The master notebook reads ETL Control metadata and automatically processes BOTH SecurityValue and OpenPosition for BOTH Little Hawk and Mitzman. You do not create separate jobs, pipeline resources, or notebooks for each table.

```text
ATWeb SQL Server  (all customers, two CDC-enabled source tables)
  |  SQL Server Agent records changes
  v
landing_history.cdc_events (all source CDC events, original changes since enabled)
  |                     \
  v                      v
landing.securityvalue     little_hawk_bronze.cdc_events -> little_hawk_silver.securityvalue/openposition
landing.openposition      mitzman_bronze.cdc_events     -> mitzman_silver.securityvalue/openposition
  |                             |
  +---------- ETL Control ------+   (9 tables configure/checkpoint/verify/estimate)
```

**Landing** = latest rows from SQL Server for all customers, including old business dates. **Landing History** = append-only CDC event journal, plus first-load baseline events. Customer **Bronze** = customer-specific events including repeated updates. Customer **Silver** = one current row for each full source primary key, with source data retained in `payload_json` for this pilot. **Gold is deliberately not part of this two-table test**; `affected_scope` identifies candidate later recalculations.

## Exact instructions — do in this order, once

### Part A: SQL Server setup — in SSMS

1. Open **SQL Server Management Studio** and connect to the SQL Server hosting the `ATWeb` database.
2. Open `sql/01_sqlserver_cdc.sql` from this package. Run only the **uncommented SELECT statements** first.
3. Have the SQL Server DBA confirm whether `ATWeb` has CDC enabled and if `dbo.SecurityValue` and `dbo.OpenPosition` have CDC enabled. The DBA alone should execute the commented `sp_cdc_enable_db` / `sp_cdc_enable_table` commands if needed. Do not execute them twice.
4. Confirm capture instance names are `dbo_SecurityValue` and `dbo_OpenPosition` as used by the seeded metadata. If the actual CDC capture names differ, update metadata values BEFORE running anything.
5. Verify SQL Server Agent capture and cleanup jobs, CDC retention, capture lag and least-privilege read access. The initial snapshot requires **a planned source-write pause and capture catch-up** for both tables; do not attempt a live non-transactional snapshot in production.

### Part B: Databricks setup — in SQL Editor

6. In the Databricks workspace open **SQL Editor → New query**.
7. Review `sql/02_uc_all_objects.sql`; confirm catalog permissions and approved ADLS managed locations. Run it in an authorized nonproduction environment. It creates: three shared schemas (`landing`, `landing_history`, `etl_control`), four customer schemas, nine control tables, Landing source-state tables, the shared journal and customer Bronze/Silver tables.
8. In another SQL Editor query, open and execute `sql/03_seed_all_metadata.sql`. It inserts or updates source and customer metadata safely using MERGE, and inserts missing checkpoints without resetting progress.
9. Open and execute `sql/05_verify_control_rows.sql`. Expected INITIAL counts (in fresh schemas): 2 source tables, 2 customers, 4 customer/table pairs, 14 pipeline dependencies, and 8 checkpoints. Four operational control tables start empty and fill only from real execution. If counts differ, investigate instead of forcing a reset.

### Part C: Databricks → SQL Server connectivity

10. Obtain a DBA-approved SQL Server JDBC hostname, port, `ATWeb` database name, and a read-only ingestion account with CDC permissions. Networking between the Databricks job compute and the private Azure VM must already be allowed.
11. Reuse your existing Databricks secret scope **`archway-sqlserver`** with the keys **`sql-user`** and **`sql-password`**. The worker notebook now uses `dw-db1.plt.archwaygroup.com:1433`, database `ATWeb`, and constructs the JDBC URL itself. It uses `encrypt=true;trustServerCertificate=true;loginTimeout=30` exactly as provided in your successful connection test. `trustServerCertificate=true` skips server certificate validation: coordinate a validated certificate and set it to `false` for production if possible. Do not create the earlier `archway-cdc` scope or `sqlserver-jdbc-url` secret.
12. Confirm the chosen job compute has a SQL Server JDBC driver and network route. Assign Unity Catalog USE/SELECT/MODIFY privileges plus necessary table creation/deployment privileges to the appropriate administrative identity. No direct Azure resource creation is specified in this package.

### Part D: Import TWO notebooks — through workspace UI

13. In Databricks left sidebar open **Workspace**. Navigate to or create `Shared / Archway / CDC` with authorized permissions.
14. Choose **Import**, import `notebooks/02_source_stage_driver.py` as a Python notebook. Verify the workspace path becomes `/Workspace/Shared/Archway/CDC/02_source_stage_driver` (the UI might show its `.py` extension differently). It is the worker: it runs the CDC, Landing, customer Bronze/Silver, reconciliation and cost stages.
15. Import `notebooks/01_ARCHWAY_CDC_MASTER.py` into the same folder. This is the only notebook you will select as your job task.
16. If your actual worker notebook path differs, supply the correct path in the `driver_path` parameter in the job; otherwise the master cannot call the worker.

### Part E: Create ONE Databricks Job in UI

17. Open **Jobs & Pipelines → Create → Job**. Name it **`JOB_ARCHWAY_CDC_MASTER`**.
18. Add **one Notebook task**. Task name: `run_master`. Notebook: `/Workspace/Shared/Archway/CDC/01_ARCHWAY_CDC_MASTER`. Select approved compute.
19. Add notebook task parameters: `mode` = `CDC`; `driver_path` = `/Workspace/Shared/Archway/CDC/02_source_stage_driver`; `max_source_tables` = `2`.
20. Set **Maximum concurrent runs = 1**. Do **not** enable the hourly schedule yet. Save job.

### Part F: FIRST run only — initial baseline/snapshot

21. Arrange an authorized SQL Server source-write pause and verify CDC has caught up; source and destination snapshots must have a consistent boundary. If not approved, **STOP HERE**. Live baseline catch-up is not yet implemented.
22. In your job choose **Run now → Run with different parameters**. Change `mode` from `CDC` to **`BASELINE`** only for this run. Click Run.
23. Master automatically gets the two enabled source tables from `source_table_config`, processes their snapshots, updates Landing, routes Little Hawk and Mitzman records, updates Silver, reconciles, and writes provisional cost weights.
24. Check run success for all stages and run `sql/06_verify_after_run.sql`. In a fresh deployment, successful Silver records exist for both customers if those customers have source rows; any zero-row table must be checked against SQL Server to determine whether legitimate. Confirm there are **no FAIL reconciliation rows** and all expected baselines are completed.
25. Only after the baseline is fully reconciled and capture caught up, authorize ending the source-write pause. Never use `BASELINE` again for the same source without a formally approved rebaseline procedure. The master skips the extract step for any source whose baseline SOURCE checkpoint is already recorded, allowing downstream baseline retry.

### Part G: Test hourly incremental CDC

26. Make one authorized test insert or update in a nonproduction source row belonging to Little Hawk; separately test Mitzman. Do **not** edit production valuation records for testing.
27. In the same job choose **Run now** and use `mode=CDC`. The master reads LSN changes for BOTH tables and routes them to the affected customer's Bronze and Silver automatically.
28. Run `sql/06_verify_after_run.sql`. Check the journal's new operations, customer Bronze changes, Silver latest values, `affected_scope` for changes, checkpoint movement, `pipeline_runs`, customer reconciliation results and provisional cost shares.
29. Test a delete and a backdated correction in a test environment. Check that Bronze retains change images and that Silver reflects the correct final state; accounting/IBOR Gold recalculation is **NOT** implemented by this pilot.
30. After your nonproduction acceptance tests are complete, open **Jobs → JOB_ARCHWAY_CDC_MASTER → Schedules & Triggers → Add trigger**, set periodic hourly execution and leave job `mode=CDC`; verify schedule timezone and permissions. Do not schedule before validation.

## How all nine control tables fill

| Table | What creates its rows | When |
|---|---|---|
| `source_table_config` | `03_seed_all_metadata.sql` | Once, then admin edits |
| `customer_registry` | `03_seed_all_metadata.sql` | Once, then onboarding |
| `customer_table_scope` | `03_seed_all_metadata.sql`; worker also marks `baseline_completed` | Once, then baseline |
| `pipeline_dependencies` | `03_seed_all_metadata.sql` | Once, then deployment edits |
| `consumer_checkpoints` | Seed; updated by extractor, Landing, customer worker | At successful stage boundaries |
| `pipeline_runs` | Worker task `logrun` | Each actual stage success/failure |
| `affected_scope` | Customer Bronze/Silver worker | Actual CDC changes (not baseline) |
| `reconciliation_results` | Reconciliation worker | After each customer/table comparison |
| `customer_cost_allocation` | Cost worker | Provisional per-customer event-volume weights (NOT USD charges) |

## One master job — what happens internally

1. **Read metadata**: two enabled source tables + four enabled customer/table pairs.
2. **EXTRACT each source**: SQL Server snapshot first time, thereafter SQL Server CDC interval by LSN; append to durable history and commit SOURCE checkpoint.
3. **LANDING each source**: replay new journal events into all-customer current-state table; commit LANDING checkpoint.
4. **BRONZE_SILVER for each customer/table**: route journal events by CustomerID, write customer Bronze, apply latest change to Silver using exact source primary key, write `affected_scope`, commit customer checkpoint.
5. **RECONCILE each customer/table**: compare Landing and Silver and write PASS/FAIL results.
6. **COST each source**: record customer work-share weights. Actual usage charges need separate billing-data integration; the notebook intentionally leaves USD and DBUs blank.

## Stop/go rules and limitations

- **This V3 package is a first controlled pilot, not yet verified in live Databricks or SQL Server.** Review permissions, source columns, datatype behavior, metadata and SQL syntax. No production claim is made.
- Direct JDBC reads of the entire SQL Server source tables can be slow and load-intensive for large initial snapshots. Define partitioned JDBC read and SQL capacity testing before high-volume deployment.
- Source writes must be paused and capture caught up during the pilot baseline. No production-safe online snapshot handoff has been built.
- Source table fields `SecurityValue.CustomerID` and `OpenPosition.FK_CustomerID` are nullable. Unresolved customer IDs are **not routed**, and current pilot does not write a dedicated exception queue. Reconciliation only covers correctly assigned rows. Treat null/unexpected customer ownership as a blocker before expanding.
- Changing CustomerID or primary key during a CDC update requires before/after owner routing. The worker blocks source-key/customer moves when detected; a production implementation needs an explicit move/removal policy.
- Delta writes to history, mirror, Bronze, Silver and ETL Control are not one database-wide transaction. The code relies on deterministic event IDs, per-stage checkpoints and repeatable merges; test failures between every stage.
- The master runs stages **serially** to keep the UI simple. If later scaling to hundreds of customers/tables, use Databricks For each + bounded concurrency, work queues and workload partitioning; you still need only one *master* Job.
- The current `affected_scope` has no resolved FundID, and **Gold layer/IBOR/ABOR recalculations are not implemented**.
- Provisional cost share is based on CDC event counts, **not measured DBUs or actual dollar charges**. Reconcile with `system.billing.usage` and a pricing table before invoicing customers.
- For actual historical audit, only mutations that SQL Server CDC captured and retained **after CDC enablement** are available; baseline records do not reconstruct earlier changes.

## Bundle inventory

`sql/01_sqlserver_cdc.sql` DBA discovery/CDC setup;
`sql/02_uc_all_objects.sql` nine control tables + Landing/History/Bronze/Silver;
`sql/03_seed_all_metadata.sql` two sources/two customers/routing/dependencies/checkpoints;
`sql/04_read_only_checks.sql` existing checks;
`sql/05_verify_control_rows.sql` nine-table counts and metadata;
`sql/06_verify_after_run.sql` example data and operational evidence;
`notebooks/01_ARCHWAY_CDC_MASTER.py` one-task metadata master;
`notebooks/02_source_stage_driver.py` worker notebook;
`ETL_Control_Data_Dictionary_V2.xlsx` nine-table field dictionary.
