# Databricks notebook source
# Single-job, metadata-driven controller for the two-source pilot.
# This notebook ORCHESTRATES data loads. It is not a Databricks Asset Bundle.
# Run as a Notebook task in a Databricks Job. Do not run concurrently.
import re
import uuid

for name, default in [
    ('mode','CDC'),
    ('driver_path','/Workspace/Shared/Archway/CDC/02_source_stage_driver'),
    ('master_run_id',''),
    ('max_source_tables','2'),
]:
    dbutils.widgets.text(name,default)

mode=dbutils.widgets.get('mode').strip().upper()
assert mode in ('BASELINE','CDC'), 'mode must be BASELINE or CDC'
driver_path=dbutils.widgets.get('driver_path').strip()
assert driver_path.startswith('/Workspace/'), 'Driver must be an approved workspace notebook'
max_tables=int(dbutils.widgets.get('max_source_tables'))
run_id=dbutils.widgets.get('master_run_id').strip() or 'MASTER_'+uuid.uuid4().hex
CT='archway_uc_dev_dw.etl_control'

# Source configuration comes ONLY from ETL Control; never hardcode customers in job tasks.
sources=[r['source_table'] for r in spark.sql(f'''
 SELECT source_table FROM {CT}.source_table_config
 WHERE is_enabled=true AND extraction_mode='DIRECT_CDC'
 ORDER BY source_table
''').collect()]
if not sources: raise RuntimeError('NO_ENABLED_SOURCE_TABLES: seed source_table_config before running')
if len(sources)>max_tables: raise RuntimeError('Too many source tables for approved pilot scope')
# Explicit pilot review: limit SQL/JDBC expression building to reviewed source definitions.
if set(sources)-{'OpenPosition','SecurityValue'}:
    raise RuntimeError('Unreviewed source table in metadata; pilot only supports SecurityValue and OpenPosition')

pairs=[(int(r['customer_id']),r['source_table']) for r in spark.sql(f'''
 SELECT s.customer_id, s.source_table
 FROM {CT}.customer_table_scope s
 JOIN {CT}.customer_registry c ON c.customer_id=s.customer_id AND c.active=true
 JOIN {CT}.source_table_config t ON t.source_table=s.source_table AND t.is_enabled=true
 WHERE s.is_enabled=true
 ORDER BY s.source_table,s.customer_id
''').collect()]
if not pairs: raise RuntimeError('NO_CUSTOMER_SCOPES: seed customer_table_scope before running')
if any(t not in sources for _,t in pairs): raise RuntimeError('Customer scope refers to disabled source')

# One master execution ID is forwarded to every stage. Each stage persists its own run audit.
print('MASTER RUN',run_id,'MODE',mode,'SOURCE TABLES',sources,'CUSTOMER/TABLE PAIRS',pairs)

def source_completed_baseline(table):
    records=spark.sql(f'''SELECT last_lsn_hex FROM {CT}.consumer_checkpoints
      WHERE consumer_id='SOURCE:{table}' ''').collect()
    if len(records)!=1: raise RuntimeError('Missing/duplicate SOURCE checkpoint for '+table)
    return records[0]['last_lsn_hex'] is not None

def call(stage,table,customer=None,task_mode=None):
    args={
       'stage':stage,
       'source_table':table,
       'customer_id':str(customer) if customer is not None else '',
       'mode':task_mode or mode,
       'run_id':run_id,
    }
    print('START',stage,table,customer)
    result=dbutils.notebook.run(driver_path,timeout_seconds=0,arguments=args)
    print('DONE',stage,table,customer,'result',result[:500] if result else 'no notebook exit value')

# Maintain stage barriers: complete all sources, then all mirrors, then all customers.
# Pilot uses serial execution; production scale can use For each tasks + bounded concurrency.
for table in sources:
    if mode=='BASELINE' and source_completed_baseline(table):
        print('Baseline EXTRACT already sealed; resume downstream stages:',table)
    else:
        call('EXTRACT',table)
for table in sources:
    call('LANDING',table)
for customer,table in pairs:
    call('BRONZE_SILVER',table,customer)
for customer,table in pairs:
    call('RECONCILE',table,customer)
for table in sources:
    call('COST',table)
print('ALL REQUESTED PILOT STAGES COMPLETED',run_id)
