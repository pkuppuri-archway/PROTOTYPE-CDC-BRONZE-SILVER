# Connection update — November 12, 2026

The SQL Server JDBC connection in `notebooks/02_source_stage_driver.py` now matches the user-confirmed connectivity test:

- Host: `dw-db1.plt.archwaygroup.com`
- Port: `1433`
- Database: `ATWeb`
- Secret scope: `archway-sqlserver`
- Secret keys: `sql-user`, `sql-password`
- JDBC properties: `encrypt=true;trustServerCertificate=true;loginTimeout=30`

Only the JDBC configuration and connection documentation changed. `01_ARCHWAY_CDC_MASTER.py`, CDC extraction and business processing logic, SQL scripts, metadata seeds and dictionary are unchanged. No actual database connection or execution was performed. For production, use TLS server certificate validation where possible.
