-- EXECUTE ONLY AFTER 02; idempotent metadata MERGEs. No customer data is processed.
MERGE INTO archway_uc_dev_dw.etl_control.source_table_config t USING (
 SELECT * FROM VALUES
 ('ATWeb','dbo','SecurityValue','dbo_SecurityValue','["SecurityValueID"]','CustomerID','SecurityValueDate','SecurityID','FK_PortfolioID',
  '["AuditUser","AuditDate","SecurityID","SecurityValueDate","SecurityValue","SecurityValueNotes","CustomerID","SecurityValueID","SecurityValue2","SecurityValue3","OutstandingShares","Volume","FK_PortfolioID","AnnualizedPayment","DisableExternalSourceUpdates","EffectiveDate","Final","Estimate","ReferenceID","Sys_BrokerID"]',true,'DIRECT_CDC',1),
 ('ATWeb','dbo','OpenPosition','dbo_OpenPosition','["OpenPositionID","Date"]','FK_CustomerID','Date','FK_SecurityID','FK_PortfolioID',
  '["OpenPositionID","FK_CustomerID","Date","FK_PortfolioID","FK_SecurityID","Quantity","CostBasis","BookValue","TaxBasis","Currency","InOpenPeriod","ReportingTaxBasis","AccumulatedUG","AccumulatedFX"]',true,'DIRECT_CDC',1)
 AS s(source_database,source_schema,source_table,capture_instance,source_pk_json,customer_column,business_date_column,security_column,portfolio_column,payload_columns_json,is_enabled,extraction_mode,schema_version)
) s ON t.source_table=s.source_table
WHEN MATCHED THEN UPDATE SET t.source_database=s.source_database,t.source_schema=s.source_schema,t.capture_instance=s.capture_instance,t.source_pk_json=s.source_pk_json,t.customer_column=s.customer_column,t.business_date_column=s.business_date_column,t.security_column=s.security_column,t.portfolio_column=s.portfolio_column,t.payload_columns_json=s.payload_columns_json,t.is_enabled=s.is_enabled,t.extraction_mode=s.extraction_mode,t.schema_version=s.schema_version,t.updated_at=current_timestamp()
WHEN NOT MATCHED THEN INSERT (source_database,source_schema,source_table,capture_instance,source_pk_json,customer_column,business_date_column,security_column,portfolio_column,payload_columns_json,is_enabled,extraction_mode,schema_version,updated_at)
VALUES(s.source_database,s.source_schema,s.source_table,s.capture_instance,s.source_pk_json,s.customer_column,s.business_date_column,s.security_column,s.portfolio_column,s.payload_columns_json,s.is_enabled,s.extraction_mode,s.schema_version,current_timestamp());
MERGE INTO archway_uc_dev_dw.etl_control.customer_registry t USING (
 SELECT * FROM VALUES
 (CAST(2020082401 AS BIGINT),'Little Hawk','little_hawk','little_hawk_bronze','little_hawk_silver',true,'CC_LITTLE_HAWK'),
 (CAST(2021080300 AS BIGINT),'Mitzman Family','mitzman','mitzman_bronze','mitzman_silver',true,'CC_MITZMAN')
 AS s(customer_id,customer_name,customer_slug,bronze_schema,silver_schema,active,cost_center)
) s ON t.customer_id=s.customer_id
WHEN MATCHED THEN UPDATE SET t.customer_name=s.customer_name,t.customer_slug=s.customer_slug,t.bronze_schema=s.bronze_schema,t.silver_schema=s.silver_schema,t.active=s.active,t.cost_center=s.cost_center,t.updated_at=current_timestamp()
WHEN NOT MATCHED THEN INSERT (customer_id,customer_name,customer_slug,bronze_schema,silver_schema,active,cost_center,updated_at)
VALUES(s.customer_id,s.customer_name,s.customer_slug,s.bronze_schema,s.silver_schema,s.active,s.cost_center,current_timestamp());
MERGE INTO archway_uc_dev_dw.etl_control.customer_table_scope t USING (
 SELECT * FROM VALUES
 (CAST(2020082401 AS BIGINT),'SecurityValue','DIRECT_CUSTOMER_ID','CustomerID',true,false),
 (CAST(2020082401 AS BIGINT),'OpenPosition','DIRECT_CUSTOMER_ID','FK_CustomerID',true,false),
 (CAST(2021080300 AS BIGINT),'SecurityValue','DIRECT_CUSTOMER_ID','CustomerID',true,false),
 (CAST(2021080300 AS BIGINT),'OpenPosition','DIRECT_CUSTOMER_ID','FK_CustomerID',true,false)
 AS s(customer_id,source_table,routing_method,routing_column,is_enabled,baseline_completed)
) s ON t.customer_id=s.customer_id AND t.source_table=s.source_table
WHEN MATCHED THEN UPDATE SET t.routing_method=s.routing_method,t.routing_column=s.routing_column,t.is_enabled=s.is_enabled,t.updated_at=current_timestamp()
WHEN NOT MATCHED THEN INSERT (customer_id,source_table,routing_method,routing_column,is_enabled,baseline_completed,updated_at)
VALUES(s.customer_id,s.source_table,s.routing_method,s.routing_column,s.is_enabled,s.baseline_completed,current_timestamp());
-- pipeline_dependencies rows enumerate every physical edge and are checked by runtime.
MERGE INTO archway_uc_dev_dw.etl_control.pipeline_dependencies t USING (
 SELECT * FROM VALUES
 ('extract_SecurityValue','EXTRACT','SecurityValue','ATWeb.dbo.SecurityValue','archway_uc_dev_dw.landing_history.cdc_events',CAST(NULL AS BIGINT),10,true),
 ('extract_OpenPosition','EXTRACT','OpenPosition','ATWeb.dbo.OpenPosition','archway_uc_dev_dw.landing_history.cdc_events',CAST(NULL AS BIGINT),10,true),
 ('mirror_SecurityValue','LANDING','SecurityValue','archway_uc_dev_dw.landing_history.cdc_events','archway_uc_dev_dw.landing.securityvalue',CAST(NULL AS BIGINT),20,true),
 ('mirror_OpenPosition','LANDING','OpenPosition','archway_uc_dev_dw.landing_history.cdc_events','archway_uc_dev_dw.landing.openposition',CAST(NULL AS BIGINT),20,true),
 ('bronze_2020082401_SecurityValue','BRONZE_SILVER','SecurityValue','archway_uc_dev_dw.landing_history.cdc_events','archway_uc_dev_dw.little_hawk_silver.securityvalue',CAST(2020082401 AS BIGINT),30,true),
 ('bronze_2020082401_OpenPosition','BRONZE_SILVER','OpenPosition','archway_uc_dev_dw.landing_history.cdc_events','archway_uc_dev_dw.little_hawk_silver.openposition',CAST(2020082401 AS BIGINT),30,true),
 ('bronze_2021080300_SecurityValue','BRONZE_SILVER','SecurityValue','archway_uc_dev_dw.landing_history.cdc_events','archway_uc_dev_dw.mitzman_silver.securityvalue',CAST(2021080300 AS BIGINT),30,true),
 ('bronze_2021080300_OpenPosition','BRONZE_SILVER','OpenPosition','archway_uc_dev_dw.landing_history.cdc_events','archway_uc_dev_dw.mitzman_silver.openposition',CAST(2021080300 AS BIGINT),30,true),
 ('reconcile_2020082401_SecurityValue','RECONCILE','SecurityValue','archway_uc_dev_dw.landing.securityvalue','archway_uc_dev_dw.little_hawk_silver.securityvalue',CAST(2020082401 AS BIGINT),40,true),
 ('reconcile_2020082401_OpenPosition','RECONCILE','OpenPosition','archway_uc_dev_dw.landing.openposition','archway_uc_dev_dw.little_hawk_silver.openposition',CAST(2020082401 AS BIGINT),40,true),
 ('reconcile_2021080300_SecurityValue','RECONCILE','SecurityValue','archway_uc_dev_dw.landing.securityvalue','archway_uc_dev_dw.mitzman_silver.securityvalue',CAST(2021080300 AS BIGINT),40,true),
 ('reconcile_2021080300_OpenPosition','RECONCILE','OpenPosition','archway_uc_dev_dw.landing.openposition','archway_uc_dev_dw.mitzman_silver.openposition',CAST(2021080300 AS BIGINT),40,true),
 ('cost_SecurityValue','COST','SecurityValue','archway_uc_dev_dw.etl_control.pipeline_runs','archway_uc_dev_dw.etl_control.customer_cost_allocation',CAST(NULL AS BIGINT),50,true),
 ('cost_OpenPosition','COST','OpenPosition','archway_uc_dev_dw.etl_control.pipeline_runs','archway_uc_dev_dw.etl_control.customer_cost_allocation',CAST(NULL AS BIGINT),50,true)
 AS s(pipeline_id,stage,source_table,input_table,output_table,customer_id,execution_order,is_enabled)
) s ON t.pipeline_id=s.pipeline_id
WHEN MATCHED THEN UPDATE SET t.stage=s.stage,t.source_table=s.source_table,t.input_table=s.input_table,t.output_table=s.output_table,t.customer_id=s.customer_id,t.execution_order=s.execution_order,t.is_enabled=s.is_enabled,t.updated_at=current_timestamp()
WHEN NOT MATCHED THEN INSERT (pipeline_id,stage,source_table,input_table,output_table,customer_id,execution_order,is_enabled,updated_at)
VALUES(s.pipeline_id,s.stage,s.source_table,s.input_table,s.output_table,s.customer_id,s.execution_order,s.is_enabled,current_timestamp());
-- Source and consumer checkpoints are initialized with NULL: NULL means no baseline completed.
INSERT INTO archway_uc_dev_dw.etl_control.consumer_checkpoints
SELECT s.consumer_id,s.input_name,s.source_table,s.customer_id,CAST(NULL AS STRING),CAST(NULL AS STRING),s.checkpoint_type,'NOT_INITIALIZED',current_timestamp()
FROM (SELECT * FROM VALUES
 ('SOURCE:SecurityValue','SQLSERVER_CDC','SecurityValue',CAST(NULL AS BIGINT),'LSN'),
 ('SOURCE:OpenPosition','SQLSERVER_CDC','OpenPosition',CAST(NULL AS BIGINT),'LSN'),
 ('LANDING:SecurityValue','JOURNAL','SecurityValue',CAST(NULL AS BIGINT),'LSN'),
 ('LANDING:OpenPosition','JOURNAL','OpenPosition',CAST(NULL AS BIGINT),'LSN'),
 ('BRONZE_SILVER:2020082401:SecurityValue','JOURNAL','SecurityValue',CAST(2020082401 AS BIGINT),'LSN'),
 ('BRONZE_SILVER:2020082401:OpenPosition','JOURNAL','OpenPosition',CAST(2020082401 AS BIGINT),'LSN'),
 ('BRONZE_SILVER:2021080300:SecurityValue','JOURNAL','SecurityValue',CAST(2021080300 AS BIGINT),'LSN'),
 ('BRONZE_SILVER:2021080300:OpenPosition','JOURNAL','OpenPosition',CAST(2021080300 AS BIGINT),'LSN')
 AS x(consumer_id,input_name,source_table,customer_id,checkpoint_type)) s
LEFT ANTI JOIN archway_uc_dev_dw.etl_control.consumer_checkpoints t ON s.consumer_id=t.consumer_id;
-- Operational tables pipeline_runs, affected_scope, reconciliation_results, customer_cost_allocation
-- are intentionally NOT given fictitious historical records. Each has a runtime writer in notebooks.
