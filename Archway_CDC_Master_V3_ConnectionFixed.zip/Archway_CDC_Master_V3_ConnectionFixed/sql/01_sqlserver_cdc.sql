/* ARCHWAY PILOT: READ-ONLY DISCOVERY; CDC ENABLE COMMANDS ARE COMMENTED OUT.
   Execute against the SQL Server hosting ATWeb. DBA approval required.
*/
SELECT name, is_cdc_enabled, state_desc FROM sys.databases WHERE name=N'ATWeb';
USE ATWeb;
SELECT t.name, t.is_tracked_by_cdc, ct.object_id AS change_tracking_object_id
FROM sys.tables t LEFT JOIN sys.change_tracking_tables ct ON ct.object_id=t.object_id
WHERE t.schema_id=SCHEMA_ID('dbo') AND t.name IN ('SecurityValue','OpenPosition');
SELECT capture_instance, source_object_id, start_lsn, supports_net_changes
FROM cdc.change_tables WHERE source_object_id IN (OBJECT_ID('dbo.SecurityValue'),OBJECT_ID('dbo.OpenPosition'));
SELECT s.name AS schema_name,t.name AS table_name,i.name AS pk_name,
       ic.key_ordinal,c.name AS key_column
FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id
JOIN sys.indexes i ON i.object_id=t.object_id AND i.is_primary_key=1
JOIN sys.index_columns ic ON ic.object_id=i.object_id AND ic.index_id=i.index_id
JOIN sys.columns c ON c.object_id=t.object_id AND c.column_id=ic.column_id
WHERE s.name='dbo' AND t.name IN ('SecurityValue','OpenPosition') ORDER BY t.name,ic.key_ordinal;
-- After DBA approval, run ONLY the required commands below, not blindly all commands:
-- USE ATWeb;
-- EXEC sys.sp_cdc_enable_db;  -- only if is_cdc_enabled=0
-- EXEC sys.sp_cdc_enable_table @source_schema=N'dbo', @source_name=N'SecurityValue',
--   @role_name=NULL, @capture_instance=N'dbo_SecurityValue', @supports_net_changes=0;
-- EXEC sys.sp_cdc_enable_table @source_schema=N'dbo', @source_name=N'OpenPosition',
--   @role_name=NULL, @capture_instance=N'dbo_OpenPosition', @supports_net_changes=0;
-- CDC capture and cleanup jobs require SQL Server Agent; obtain DBA-approved retention.
-- EXEC sys.sp_cdc_help_jobs;
-- Example (DBA only) for 7-day retention: EXEC sys.sp_cdc_change_job @job_type=N'cleanup', @retention=10080;
-- EXEC sys.sp_cdc_stop_job @job_type=N'cleanup'; EXEC sys.sp_cdc_start_job @job_type=N'cleanup';
-- Enable CDC and allow permissions SELECT on the captured columns and CDC access.
