-- Run in Databricks SQL editor. READ ONLY. Run after the metadata seed.
SELECT 'source_table_config' table_name, count(*) rows FROM archway_uc_dev_dw.etl_control.source_table_config
UNION ALL SELECT 'customer_registry',count(*) FROM archway_uc_dev_dw.etl_control.customer_registry
UNION ALL SELECT 'customer_table_scope',count(*) FROM archway_uc_dev_dw.etl_control.customer_table_scope
UNION ALL SELECT 'pipeline_dependencies',count(*) FROM archway_uc_dev_dw.etl_control.pipeline_dependencies
UNION ALL SELECT 'consumer_checkpoints',count(*) FROM archway_uc_dev_dw.etl_control.consumer_checkpoints
UNION ALL SELECT 'pipeline_runs',count(*) FROM archway_uc_dev_dw.etl_control.pipeline_runs
UNION ALL SELECT 'affected_scope',count(*) FROM archway_uc_dev_dw.etl_control.affected_scope
UNION ALL SELECT 'reconciliation_results',count(*) FROM archway_uc_dev_dw.etl_control.reconciliation_results
UNION ALL SELECT 'customer_cost_allocation',count(*) FROM archway_uc_dev_dw.etl_control.customer_cost_allocation;

SELECT source_table,capture_instance,source_pk_json,is_enabled FROM archway_uc_dev_dw.etl_control.source_table_config ORDER BY source_table;
SELECT customer_id,customer_name,bronze_schema,silver_schema,active FROM archway_uc_dev_dw.etl_control.customer_registry ORDER BY customer_id;
SELECT customer_id,source_table,baseline_completed FROM archway_uc_dev_dw.etl_control.customer_table_scope ORDER BY source_table,customer_id;
SELECT consumer_id,last_lsn_hex,status FROM archway_uc_dev_dw.etl_control.consumer_checkpoints ORDER BY consumer_id;
