-- ARCHWAY V2: PROPOSED objects; review UC managed locations, grants and identities.
-- Do not run until catalog ownership / target storage are approved.
CREATE SCHEMA IF NOT EXISTS archway_uc_dev_dw.landing;
CREATE SCHEMA IF NOT EXISTS archway_uc_dev_dw.landing_history;
CREATE SCHEMA IF NOT EXISTS archway_uc_dev_dw.etl_control;
CREATE SCHEMA IF NOT EXISTS archway_uc_dev_dw.little_hawk_bronze;
CREATE SCHEMA IF NOT EXISTS archway_uc_dev_dw.little_hawk_silver;
CREATE SCHEMA IF NOT EXISTS archway_uc_dev_dw.mitzman_bronze;
CREATE SCHEMA IF NOT EXISTS archway_uc_dev_dw.mitzman_silver;

-- NINE required control tables; runtime writers use every one.
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.etl_control.source_table_config (
  source_database STRING, source_schema STRING, source_table STRING, capture_instance STRING,
  source_pk_json STRING, customer_column STRING, business_date_column STRING,
  security_column STRING, portfolio_column STRING, payload_columns_json STRING,
  is_enabled BOOLEAN, extraction_mode STRING, schema_version INT, updated_at TIMESTAMP
) USING DELTA;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.etl_control.customer_registry (
  customer_id BIGINT, customer_name STRING, customer_slug STRING, bronze_schema STRING,
  silver_schema STRING, active BOOLEAN, cost_center STRING, updated_at TIMESTAMP
) USING DELTA;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.etl_control.customer_table_scope (
  customer_id BIGINT, source_table STRING, routing_method STRING, routing_column STRING,
  is_enabled BOOLEAN, baseline_completed BOOLEAN, updated_at TIMESTAMP
) USING DELTA;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.etl_control.pipeline_dependencies (
  pipeline_id STRING, stage STRING, source_table STRING, input_table STRING,
  output_table STRING, customer_id BIGINT, execution_order INT, is_enabled BOOLEAN, updated_at TIMESTAMP
) USING DELTA;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.etl_control.consumer_checkpoints (
  consumer_id STRING, input_name STRING, source_table STRING, customer_id BIGINT,
  last_lsn_hex STRING, last_run_id STRING, checkpoint_type STRING, status STRING, updated_at TIMESTAMP
) USING DELTA;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.etl_control.pipeline_runs (
  run_id STRING, task_id STRING, stage STRING, source_table STRING, customer_id BIGINT,
  started_at TIMESTAMP, ended_at TIMESTAMP, status STRING, from_lsn_hex STRING,
  to_lsn_hex STRING, rows_read BIGINT, rows_written BIGINT, error_message STRING
) USING DELTA;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.etl_control.affected_scope (
  impact_id STRING, event_id STRING, customer_id BIGINT, source_table STRING,
  fund_id BIGINT, portfolio_id BIGINT, security_id BIGINT, effective_date DATE,
  reason STRING, processing_status STRING, created_at TIMESTAMP
) USING DELTA;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.etl_control.reconciliation_results (
  reconcile_id STRING, run_id STRING, customer_id BIGINT, source_table STRING,
  check_name STRING, expected_count BIGINT, actual_count BIGINT, mismatch_count BIGINT,
  status STRING, checked_at TIMESTAMP, details STRING
) USING DELTA;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.etl_control.customer_cost_allocation (
  allocation_id STRING, run_id STRING, customer_id BIGINT, cost_center STRING,
  allocation_basis STRING, weight DOUBLE, measured_dbu DOUBLE,
  measured_usd DECIMAL(18,6), allocation_status STRING, calculated_at TIMESTAMP
) USING DELTA;

-- Cross-customer durable journal and synchronized current-state mirror.
-- For full audit, journal is populated by SQL Server CDC direct; NO Lakeflow CDC coalescing.
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.landing_history.cdc_events (
  event_id STRING, source_table STRING, capture_instance STRING, source_key STRING,
  lsn_hex STRING, seq_hex STRING, operation INT, operation_name STRING,
  customer_id BIGINT, security_id BIGINT, portfolio_id BIGINT, business_date DATE,
  payload_json STRING, run_id STRING, ingested_at TIMESTAMP
) USING DELTA TBLPROPERTIES (delta.enableChangeDataFeed=true);
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.landing.securityvalue (
  source_key STRING, security_value_id BIGINT, customer_id BIGINT, security_id BIGINT,
  portfolio_id BIGINT, business_date DATE, payload_json STRING,
  last_lsn_hex STRING, last_seq_hex STRING, updated_at TIMESTAMP
) USING DELTA TBLPROPERTIES (delta.enableChangeDataFeed=true);
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.landing.openposition (
  source_key STRING, open_position_id BIGINT, position_date TIMESTAMP, customer_id BIGINT,
  security_id BIGINT, portfolio_id BIGINT, business_date DATE, payload_json STRING,
  last_lsn_hex STRING, last_seq_hex STRING, updated_at TIMESTAMP
) USING DELTA TBLPROPERTIES (delta.enableChangeDataFeed=true);
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.little_hawk_bronze.cdc_events LIKE archway_uc_dev_dw.landing_history.cdc_events;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.mitzman_bronze.cdc_events LIKE archway_uc_dev_dw.landing_history.cdc_events;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.little_hawk_silver.securityvalue LIKE archway_uc_dev_dw.landing.securityvalue;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.mitzman_silver.securityvalue LIKE archway_uc_dev_dw.landing.securityvalue;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.little_hawk_silver.openposition LIKE archway_uc_dev_dw.landing.openposition;
CREATE TABLE IF NOT EXISTS archway_uc_dev_dw.mitzman_silver.openposition LIKE archway_uc_dev_dw.landing.openposition;
-- IMPORTANT: these table patterns represent physical state, source columns persist in payload_json.
-- Production may expand typed fields and stronger DQ/validations before Gold.
