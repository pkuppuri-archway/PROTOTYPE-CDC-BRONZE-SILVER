-- DATA/CONTROL CHECKS: read-only; run after seed or after pipeline execution.
SELECT 'source_table_config' AS control_table, count(*) AS rows FROM archway_uc_dev_dw.etl_control.source_table_config
UNION ALL SELECT 'customer_registry',count(*) FROM archway_uc_dev_dw.etl_control.customer_registry
UNION ALL SELECT 'customer_table_scope',count(*) FROM archway_uc_dev_dw.etl_control.customer_table_scope
UNION ALL SELECT 'pipeline_dependencies',count(*) FROM archway_uc_dev_dw.etl_control.pipeline_dependencies
UNION ALL SELECT 'consumer_checkpoints',count(*) FROM archway_uc_dev_dw.etl_control.consumer_checkpoints
UNION ALL SELECT 'pipeline_runs',count(*) FROM archway_uc_dev_dw.etl_control.pipeline_runs
UNION ALL SELECT 'affected_scope',count(*) FROM archway_uc_dev_dw.etl_control.affected_scope
UNION ALL SELECT 'reconciliation_results',count(*) FROM archway_uc_dev_dw.etl_control.reconciliation_results
UNION ALL SELECT 'customer_cost_allocation',count(*) FROM archway_uc_dev_dw.etl_control.customer_cost_allocation;
SELECT * FROM archway_uc_dev_dw.etl_control.consumer_checkpoints ORDER BY consumer_id;
SELECT * FROM archway_uc_dev_dw.etl_control.pipeline_runs ORDER BY started_at DESC LIMIT 100;
SELECT * FROM archway_uc_dev_dw.etl_control.reconciliation_results ORDER BY checked_at DESC LIMIT 100;
SELECT * FROM archway_uc_dev_dw.etl_control.customer_cost_allocation ORDER BY calculated_at DESC LIMIT 100;
