-- Databricks SQL editor: READ ONLY.
SELECT source_table,operation_name,count(*) AS events FROM archway_uc_dev_dw.landing_history.cdc_events GROUP BY source_table,operation_name ORDER BY source_table,operation_name;
SELECT 'landing.securityvalue' AS layer,count(*) AS rows FROM archway_uc_dev_dw.landing.securityvalue
UNION ALL SELECT 'landing.openposition',count(*) FROM archway_uc_dev_dw.landing.openposition
UNION ALL SELECT 'little_hawk_silver.securityvalue',count(*) FROM archway_uc_dev_dw.little_hawk_silver.securityvalue
UNION ALL SELECT 'little_hawk_silver.openposition',count(*) FROM archway_uc_dev_dw.little_hawk_silver.openposition
UNION ALL SELECT 'mitzman_silver.securityvalue',count(*) FROM archway_uc_dev_dw.mitzman_silver.securityvalue
UNION ALL SELECT 'mitzman_silver.openposition',count(*) FROM archway_uc_dev_dw.mitzman_silver.openposition;
SELECT run_id,task_id,status,rows_read,rows_written,error_message FROM archway_uc_dev_dw.etl_control.pipeline_runs ORDER BY ended_at DESC LIMIT 40;
SELECT customer_id,source_table,status,expected_count,actual_count,mismatch_count FROM archway_uc_dev_dw.etl_control.reconciliation_results ORDER BY checked_at DESC LIMIT 20;
SELECT customer_id,cost_center,allocation_basis,weight,allocation_status,measured_usd FROM archway_uc_dev_dw.etl_control.customer_cost_allocation ORDER BY calculated_at DESC LIMIT 20;
SELECT source_table,customer_id,security_id,portfolio_id,effective_date,processing_status FROM archway_uc_dev_dw.etl_control.affected_scope ORDER BY created_at DESC LIMIT 25;
