# Databricks notebook source; Python notebook task. NO automatic execution on import.
# stage = EXTRACT | LANDING | BRONZE_SILVER | RECONCILE | COST
# mode = BASELINE | CDC (only EXTRACT); source_table=SecurityValue|OpenPosition
# run_id shared across job tasks. Customer required for BRONZE_SILVER and RECONCILE.
# Single in-flight job per source is required. Initial BASELINE needs coordinated ATWeb write pause.
import json, uuid, hashlib
from pyspark.sql import functions as F, Window
from pyspark.sql.types import *
from delta.tables import DeltaTable

CAT='archway_uc_dev_dw'; CT=f'{CAT}.etl_control'; JOURNAL=f'{CAT}.landing_history.cdc_events'
for key,default in [('stage','EXTRACT'),('source_table','SecurityValue'),('customer_id',''),('mode','CDC'),('run_id','')]:
    dbutils.widgets.text(key,default)
stage=dbutils.widgets.get('stage').upper()
table=dbutils.widgets.get('source_table')
mode=dbutils.widgets.get('mode').upper()
customer_arg=dbutils.widgets.get('customer_id').strip()
customer=int(customer_arg) if customer_arg else None
run_id=dbutils.widgets.get('run_id') or uuid.uuid4().hex
assert stage in ('EXTRACT','LANDING','BRONZE_SILVER','RECONCILE','COST')
if table not in ('SecurityValue','OpenPosition'): raise ValueError('Pilot supports only two reviewed ATWeb tables')
if stage in ('BRONZE_SILVER','RECONCILE') and customer is None: raise ValueError('customer_id is required')
task_id=f'{stage}:{table}:{customer if customer is not None else "ALL"}'

# IMPORTANT: use SQL table reads + no passwords in source. Only EXTRACT requires JDBC.
def one(sql):
    return spark.sql(sql).first()
def esc(value):
    return "'"+str(value).replace("'","''")+"'"
def dmerge(table_name,df,match):
    (DeltaTable.forName(spark,table_name).alias('t').merge(df.alias('s'),match)
     .whenMatchedUpdateAll().whenNotMatchedInsertAll().execute())
def checkpoint_id(kind):
    return f'{kind}:{customer}:{table}' if kind=='BRONZE_SILVER' else f'{kind}:{table}'
def read_checkpoint(kind):
    ident=checkpoint_id(kind)
    r=one(f'SELECT last_lsn_hex FROM {CT}.consumer_checkpoints WHERE consumer_id={esc(ident)}')
    if not r: raise RuntimeError('Missing seeded checkpoint '+ident)
    return r[0]
def save_checkpoint(kind,lsn):
    ident=checkpoint_id(kind)
    df=(spark.createDataFrame([(ident,'SQLSERVER_CDC' if kind=='SOURCE' else 'JOURNAL',table,customer if kind=='BRONZE_SILVER' else None,lsn,run_id,'LSN','COMPLETED')],
         'consumer_id STRING,input_name STRING,source_table STRING,customer_id LONG,last_lsn_hex STRING,last_run_id STRING,checkpoint_type STRING,status STRING')
         .withColumn('updated_at',F.current_timestamp()))
    dmerge(f'{CT}.consumer_checkpoints',df,'t.consumer_id=s.consumer_id')
def logrun(status,rows_read=0,rows_written=0,error=None,from_lsn=None,to_lsn=None):
    df=(spark.createDataFrame([(run_id,task_id,stage,table,customer,status,from_lsn,to_lsn,int(rows_read),int(rows_written),error)],
         'run_id STRING,task_id STRING,stage STRING,source_table STRING,customer_id LONG,status STRING,from_lsn_hex STRING,to_lsn_hex STRING,rows_read LONG,rows_written LONG,error_message STRING')
         .withColumn('started_at',F.current_timestamp()).withColumn('ended_at',F.current_timestamp()))
    dmerge(f'{CT}.pipeline_runs',df,'t.run_id=s.run_id AND t.task_id=s.task_id')
def check_dependency():
    name=({'EXTRACT':f'extract_{table}','LANDING':f'mirror_{table}','BRONZE_SILVER':f'bronze_{customer}_{table}',
           'RECONCILE':f'reconcile_{customer}_{table}','COST':f'cost_{table}'})[stage]
    r=one(f'SELECT count(*) FROM {CT}.pipeline_dependencies WHERE pipeline_id={esc(name)} AND is_enabled=true')
    if r[0]!=1: raise RuntimeError('Missing/disabled dependency '+name)
    r=one(f'SELECT count(*) FROM {CT}.source_table_config WHERE source_table={esc(table)} AND is_enabled=true')
    if r[0]!=1: raise RuntimeError('Source configuration missing or duplicated')
    if customer:
        r=one(f'SELECT count(*) FROM {CT}.customer_table_scope WHERE customer_id={customer} AND source_table={esc(table)} AND is_enabled=true')
        if r[0]!=1: raise RuntimeError('Customer source scope missing or duplicated')
check_dependency()

config=one(f'SELECT * FROM {CT}.source_table_config WHERE source_table={esc(table)}')
cols=json.loads(config['payload_columns_json']); pk=json.loads(config['source_pk_json'])
customer_col=config['customer_column']; sec_col=config['security_column']; port_col=config['portfolio_column']; date_col=config['business_date_column']

# One source event has an immutable deterministic identity, independent of retry run id.
def normalize(raw, baseline=False):
    payload=F.to_json(F.struct(*[F.col(c) for c in cols]))
    key=F.to_json(F.struct(*[F.col(k) for k in pk]))
    lsn=F.col('_lsn_hex'); seq=F.col('_seq_hex'); op=F.col('_op')
    res=(raw.withColumn('_payload',payload).withColumn('_key',key)
        .withColumn('_event',F.sha2(F.concat_ws('|',F.lit(table),lsn,seq,op.cast('string'),key,payload),256)))
    return res.select(F.col('_event').alias('event_id'),F.lit(table).alias('source_table'),
        F.lit(config['capture_instance']).alias('capture_instance'),F.col('_key').alias('source_key'),
        lsn.alias('lsn_hex'),seq.alias('seq_hex'),op.alias('operation'),
        F.expr("CASE _op WHEN 0 THEN 'BASELINE' WHEN 1 THEN 'DELETE' WHEN 2 THEN 'INSERT' WHEN 3 THEN 'UPDATE_BEFORE' WHEN 4 THEN 'UPDATE_AFTER' END").alias('operation_name'),
        F.col(customer_col).cast('long').alias('customer_id'),
        F.col(sec_col).cast('long').alias('security_id'),
        F.col(port_col).cast('long').alias('portfolio_id'),
        F.to_date(F.col(date_col)).alias('business_date'),F.col('_payload').alias('payload_json'),
        F.lit(run_id).alias('run_id'),F.current_timestamp().alias('ingested_at'))

def jdbc_query(sql):
    url=dbutils.secrets.get('archway-cdc','sqlserver-jdbc-url')
    usr=dbutils.secrets.get('archway-cdc','username'); pwd=dbutils.secrets.get('archway-cdc','password')
    return spark.read.jdbc(url=url,table=f'({sql}) AS src',properties={'user':usr,'password':pwd,'driver':'com.microsoft.sqlserver.jdbc.SQLServerDriver'})
def max_lsn():
    return jdbc_query('SELECT CONVERT(varchar(20),sys.fn_cdc_get_max_lsn(),2) AS h').first()['h'].upper()
def min_lsn():
    return jdbc_query('SELECT CONVERT(varchar(20),sys.fn_cdc_get_min_lsn('+esc(config['capture_instance'])+'),2) AS l').first()['l'].upper()

def get_batch(kind):
    """Read durable history after this consumer's LSN and through SOURCE's sealed high LSN."""
    upper=read_checkpoint('SOURCE')
    if upper is None: raise RuntimeError('SOURCE not initialized; run BASELINE first')
    previous=read_checkpoint(kind)
    base=spark.table(JOURNAL).where(F.col('source_table')==table)
    if previous: base=base.where(F.col('lsn_hex')>previous)
    base=base.where(F.col('lsn_hex')<=upper)
    return base,upper,previous

def project_state(events):
    """One latest applicable event per exact source key: 0/2/4 upsert, 1 delete."""
    relevant=events.where(F.col('operation').isin([0,1,2,4]))
    w=Window.partitionBy('source_key').orderBy(F.col('lsn_hex').desc(),F.col('seq_hex').desc(),F.col('operation').desc())
    final=relevant.withColumn('_rn',F.row_number().over(w)).where('_rn=1').drop('_rn')
    body=final.withColumn('doc',F.from_json('payload_json',get_payload_schema()))
    common=[F.col('source_key'),F.col('customer_id'),F.col('security_id'),F.col('portfolio_id'),
            F.col('business_date'),F.col('payload_json'),F.col('lsn_hex').alias('last_lsn_hex'),
            F.col('seq_hex').alias('last_seq_hex'),F.current_timestamp().alias('updated_at')]
    if table=='SecurityValue':
        body=body.select(*common,F.col('doc.SecurityValueID').cast('long').alias('security_value_id'),F.col('operation'))
        cols_order=['source_key','security_value_id','customer_id','security_id','portfolio_id','business_date','payload_json','last_lsn_hex','last_seq_hex','updated_at','operation']
    else:
        body=body.select(*common,F.col('doc.OpenPositionID').cast('long').alias('open_position_id'),F.col('doc.Date').cast('timestamp').alias('position_date'),F.col('operation'))
        cols_order=['source_key','open_position_id','position_date','customer_id','security_id','portfolio_id','business_date','payload_json','last_lsn_hex','last_seq_hex','updated_at','operation']
    return body.select(*cols_order)

def get_payload_schema():
    # String parsing for ids and measures avoids lossy DOUBLE coercions in payload.
    return StructType([StructField(c,StringType(),True) for c in cols])

def apply_state(target,final):
    # Reject source-key/customer movement in this pilot: expansion needs old/new ownership routing.
    existing=spark.table(target).select('source_key','customer_id').alias('old')
    changed=(final.alias('new').join(existing,'source_key','inner')
        .where(~F.col('new.customer_id').eqNullSafe(F.col('old.customer_id'))).limit(1).count())
    if changed: raise RuntimeError('CUSTOMER_MOVEMENT_UNSUPPORTED: quarantine/extend routing before advancing checkpoint')
    cond='t.source_key=s.source_key'
    source=final
    # Idempotence across retries: only apply events newer than target's stored source sequence.
    newer='(t.last_lsn_hex IS NULL OR s.last_lsn_hex > t.last_lsn_hex OR (s.last_lsn_hex=t.last_lsn_hex AND s.last_seq_hex>=t.last_seq_hex))'
    field_names=[c for c in source.columns if c!='operation']
    update={c:f's.{c}' for c in field_names}
    insert={c:f's.{c}' for c in field_names}
    (DeltaTable.forName(spark,target).alias('t').merge(source.alias('s'),cond)
      .whenMatchedDelete(condition=f's.operation=1 AND {newer}')
      .whenMatchedUpdate(condition=f's.operation<>1 AND {newer}',set=update)
      .whenNotMatchedInsert(condition='s.operation<>1',values=insert).execute())

def do_extract():
    old=read_checkpoint('SOURCE')
    high=max_lsn()
    low=min_lsn()
    if mode=='BASELINE':
        if old is not None: raise RuntimeError('Baseline already initialized; do not repeat without explicit reset and rebaseline')
        # Precondition: writes paused and SQL Server CDC capture caught up; see runbook.
        raw=jdbc_query('SELECT '+','.join('['+c+']' for c in cols)+f' FROM [dbo].[{table}]')
        raw=raw.withColumn('_lsn_hex',F.lit('0'*20)).withColumn('_seq_hex',F.lit('0'*20)).withColumn('_op',F.lit(0))
    else:
        if not old: raise RuntimeError('No completed BASELINE: stop to avoid missing history')
        if old < low: raise RuntimeError('CDC_RETENTION_GAP: SQL Server cleaned data before extraction')
        if old==high: save_checkpoint('SOURCE',high); return 0,0,old,high
        if old>high: raise RuntimeError('LSN regression: restore or failover suspected')
        capture=config['capture_instance']
        # JDBC literal 0x prefixed binary converted with style 1, INCLUSIVE lower/upper.
        start=f"sys.fn_cdc_increment_lsn(CONVERT(binary(10),'0x{old}',1))"
        cdc_sql=('SELECT '+','.join(f'c.[{c}]' for c in cols)+
            ',CONVERT(varchar(20),c.__$start_lsn,2) AS _lsn_hex,'+
            'CONVERT(varchar(20),c.__$seqval,2) AS _seq_hex,c.__$operation AS _op '+
            f"FROM cdc.fn_cdc_get_all_changes_{capture}({start},CONVERT(binary(10),'0x{high}',1),'all update old') c")
        raw=jdbc_query(cdc_sql)
    events=normalize(raw)
    # Reject ambiguous source CDC before-images where customer or key moves across UPDATE event.
    # A full production implementation should build old-owner DELETE and new-owner UPSERT.
    if mode=='CDC':
        oldrows=events.where(F.col('operation')==3).select('lsn_hex','seq_hex',F.col('customer_id').alias('old_customer'),F.col('source_key').alias('old_key'))
        newrows=events.where(F.col('operation')==4).select('lsn_hex','seq_hex',F.col('customer_id').alias('new_customer'),F.col('source_key').alias('new_key'))
        moved=(oldrows.join(newrows,['lsn_hex','seq_hex'],'inner')
              .where(~F.col('old_customer').eqNullSafe(F.col('new_customer')) | (F.col('old_key')!=F.col('new_key'))).limit(1).count())
        if moved: raise RuntimeError('SOURCE_KEY_OR_CUSTOMER_MOVEMENT: requires explicit old/new routing; source checkpoint NOT advanced')
    event_count=events.count()
    (DeltaTable.forName(spark,JOURNAL).alias('t').merge(events.alias('s'),'t.event_id=s.event_id')
      .whenNotMatchedInsertAll().execute())
    save_checkpoint('SOURCE',high)
    return event_count,event_count,old,high

def do_landing():
    batch,upper,prev=get_batch('LANDING')
    n=batch.count()
    if n:
        state=project_state(batch)
        apply_state(f'{CAT}.landing.{table.lower()}',state)
    save_checkpoint('LANDING',upper)
    return n,n,prev,upper

def do_customer():
    reg=one(f'SELECT bronze_schema,silver_schema FROM {CT}.customer_registry WHERE customer_id={customer} AND active=true')
    if not reg: raise RuntimeError('Inactive or unregistered customer')
    batch,upper,prev=get_batch('BRONZE_SILVER')
    # before-images always included for auditing customer history, but only apply 0/1/2/4 to Silver.
    # Unresolved customer ids cannot be guessed; record exception and block only relevant customer routing.
    scoped=batch.where(F.col('customer_id')==customer)
    n=scoped.count()
    if n:
        bronze=f'{CAT}.{reg["bronze_schema"]}.cdc_events'
        (DeltaTable.forName(spark,bronze).alias('t').merge(scoped.alias('s'),'t.event_id=s.event_id')
          .whenNotMatchedInsertAll().execute())
        state=project_state(scoped)
        silver=f'{CAT}.{reg["silver_schema"]}.{table.lower()}'
        apply_state(silver,state)
        impacts=(scoped.where(F.col('operation').isin([1,2,4]))
          .withColumn('impact_id',F.sha2(F.concat_ws('|','event_id',F.lit(str(customer))),256))
          .select('impact_id','event_id',F.lit(customer).cast('long').alias('customer_id'),
             'source_table',F.lit(None).cast('long').alias('fund_id'),'portfolio_id','security_id',
             F.col('business_date').alias('effective_date'),
             F.lit('SOURCE_CDC_CHANGED').alias('reason'),
             F.lit('PENDING_FUND_RESOLUTION').alias('processing_status'),F.current_timestamp().alias('created_at')))
        (DeltaTable.forName(spark,f'{CT}.affected_scope').alias('t')
         .merge(impacts.alias('s'),'t.impact_id=s.impact_id').whenNotMatchedInsertAll().execute())
    # Do not skip unseen events: advance even when zero belong to this customer.
    save_checkpoint('BRONZE_SILVER',upper)
    # Mark baseline for this customer/table only AFTER customer silver successfully applied.
    spark.sql(f"UPDATE {CT}.customer_table_scope SET baseline_completed=true,updated_at=current_timestamp() "
              f"WHERE customer_id={customer} AND source_table={esc(table)}")
    return n,n,prev,upper

def do_reconcile():
    reg=one(f'SELECT silver_schema FROM {CT}.customer_registry WHERE customer_id={customer} AND active=true')
    if not reg: raise RuntimeError('Customer registry missing')
    landing=spark.table(f'{CAT}.landing.{table.lower()}').where(F.col('customer_id')==customer)
    silver=spark.table(f'{CAT}.{reg["silver_schema"]}.{table.lower()}')
    lcnt=landing.count(); scnt=silver.count()
    # Match exact source keys + payload from landing current state against customer silver.
    left=landing.select('source_key','payload_json')
    right=silver.select('source_key','payload_json')
    missing=left.join(right,['source_key','payload_json'],'left_anti').count()
    unexpected=right.join(left,['source_key','payload_json'],'left_anti').count()
    duplicate=silver.groupBy('source_key').count().where('count>1').count()
    failed=missing+unexpected+duplicate
    result='PASS' if failed==0 and lcnt==scnt else 'FAIL'
    rec=(spark.createDataFrame([(f'{run_id}:{customer}:{table}:SOURCE_TO_SILVER',run_id,customer,table,
        'SOURCE_TO_SILVER',lcnt,scnt,failed,result,
        json.dumps({'missing_or_different':missing,'unexpected_or_different':unexpected,'duplicate_keys':duplicate}))],
        'reconcile_id STRING,run_id STRING,customer_id LONG,source_table STRING,check_name STRING,expected_count LONG,actual_count LONG,mismatch_count LONG,status STRING,details STRING')
        .withColumn('checked_at',F.current_timestamp()))
    dmerge(f'{CT}.reconciliation_results',rec,'t.reconcile_id=s.reconcile_id')
    if result!='PASS': raise RuntimeError(f'RECONCILIATION_FAILED source={lcnt} silver={scnt} mismatch={failed}')
    return lcnt,scnt,None,None

def do_cost():
    # Usage shares are measured from rows handled by this run, NOT billed dollars.
    # Replace measured_dbu/usd from system.billing.usage with trusted pricing and job attribution.
    rows=spark.sql(f"SELECT cr.customer_id,COALESCE(p.volume,0) AS volume FROM {CT}.customer_registry cr "
        f"LEFT JOIN (SELECT customer_id,sum(rows_read) AS volume FROM {CT}.pipeline_runs "
        f"WHERE run_id={esc(run_id)} AND source_table={esc(table)} AND stage='BRONZE_SILVER' "
        "AND status='COMPLETED' GROUP BY customer_id) p ON cr.customer_id=p.customer_id "
        f"WHERE cr.active=true AND EXISTS (SELECT 1 FROM {CT}.customer_table_scope scope WHERE scope.customer_id=cr.customer_id AND scope.source_table={esc(table)} AND scope.is_enabled=true)").collect()
    total=sum(r['volume'] or 0 for r in rows)
    for r in rows:
        cid=int(r['customer_id'])
        registry=one(f'SELECT cost_center FROM {CT}.customer_registry WHERE customer_id={cid}')
        weight=float((r['volume'] or 0)/total) if total else 0.0
        d=(spark.createDataFrame([(f'{run_id}:{table}:{cid}',run_id,cid,registry['cost_center'],
                'CUSTOMER_CDC_EVENT_VOLUME',weight,None,None,'PENDING_BILLING_ATTRIBUTION')],
             'allocation_id STRING,run_id STRING,customer_id LONG,cost_center STRING,allocation_basis STRING,weight DOUBLE,measured_dbu DOUBLE,measured_usd DECIMAL(18,6),allocation_status STRING')
          .withColumn('calculated_at',F.current_timestamp()))
        dmerge(f'{CT}.customer_cost_allocation',d,'t.allocation_id=s.allocation_id')
    return len(rows),len(rows),None,None

try:
    fn={'EXTRACT':do_extract,'LANDING':do_landing,'BRONZE_SILVER':do_customer,'RECONCILE':do_reconcile,'COST':do_cost}[stage]
    read,write,lo,hi=fn()
    logrun('COMPLETED',read,write,from_lsn=lo,to_lsn=hi)
    print({'status':'COMPLETED','stage':stage,'source':table,'customer':customer,'read':read,'written':write,'run_id':run_id})
except Exception as e:
    logrun('FAILED',error=str(e)[:3500])
    raise
